@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card h-100">
                <img style="height: 150px;" src="{{asset('img/logofinal.png')}}">
                <div class="card-body">
                    <p>
                        Bienvenido al Software Administrativo de Aiza Boutique, para ingresar vaya a la pestaña de login e inicie session con su respectivo Usuario y Contraseña, si no tiene Usuario Asignado, Favor registrarse en el sistema, Gracias...
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection