@extends('layouts.app')
@section('content')
    <div class="full-box text-center">
        <article class="full-box tile">
            <div class="full-box tile-title text-center text-titles text-uppercase">
                {{ Auth::user()->name }}
            </div>
            <div class="full-box tile-icon text-center">
				<h3>{{ Auth::user()->roles->first()->name }}</h3>
			</div>
        </article>
    </div>
@endsection
