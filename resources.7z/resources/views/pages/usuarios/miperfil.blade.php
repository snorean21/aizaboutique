@extends('layouts.app')
@section('title', 'Mi perfil')
@section('breadcrumbs')
	<!-- Breadcrumbs-->
      	<ol class="breadcrumb">
            <li class="breadcrumb-item">
              	<a href="{{url('home')}}">Inicio</a>
            </li>
            <li class="breadcrumb-item active">Mi perfil</li>
      	</ol>
    <!-- Cierra Breadcrumbs -->
@endsection
@section('content')
	@include('layouts.components.error')
	<div class="card mb-3">
		<div class="card-header">
			<i class="fas fa-table"></i>
			Mostrando perfil de {{ Auth::user()->name }}
		</div>
		<div class="card-body">
			<div class="table-responsive">
				{!! Form::model($user, ['route'=>['user.update', $user->id], 'method'=>'PUT', 'class'=>'form-group']) !!}
						<div class="accordion" id="accordionExample" style="width: 500px">
							<div class="card">
								<div class="card-header" id="headingOne">
									<h5 class="mb-0">
										<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										Informacion general
										</button>
									</h5>
								</div>
								<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
									<div class="card-body">

									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingTwo">
									<h5 class="mb-0">
										<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										Informacion personal
										</button>
									</h5>
								</div>
								<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
									<div class="card-body">
										<div class="form-group">
											<div class="card" style="width: 100%;">
													<img class="card-img-top" src="{{ Storage::url($user->avatar) }}" alt="Card image cap" style="width: 200px; margin: 10px auto;">
												<div class="card-body">
													{!! Form::label('avatar', 'Nombre Usuario') !!}
										   			{!! Form::file('avatar', null, ['class' => 'form-control']) !!}
												</div>
											</div>
										</div>
										<div class="form-group">
											{!! Form::label('name', 'Nombre Usuario') !!}
										    {!! Form::text('name', null, ['class' => 'form-control']) !!}
										</div>
										<div class="form-group">
											{!! Form::label('name', 'Nombre Usuario') !!}
										    {!! Form::text('name', null, ['class' => 'form-control']) !!}
										</div>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingThree">
									<h5 class="mb-0">
										<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
											Familia y Relaciones
										</button>
									</h5>
								</div>
								<div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">
									<div class="card-body">
										<h6>Situacion Sentimental</h6>
										<hr>
										<p>
											<a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1"><i class="zmdi zmdi-home"></i></a>
										</p>
										<div class="row">
											<div class="col">
											    <div class="collapse multi-collapse" id="multiCollapseExample1">
											    	<div class="card card-body">
														sdas
											    	</div>
											    </div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card">
								<div class="card-header" id="headingfour">
									<h5 class="mb-0">
										<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
										Collapsible Group Item #4
										</button>
									</h5>
								</div>
								<div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordionExample">
									<div class="card-body">
									Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
									</div>
								</div>
							</div>
						</div>

						{{-- <thead>
							<tr>
								<th>Nombre Usuario</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td style="vertical-align: middle;">
									{!! Form::text('name', null, ['class' => 'form-control text-center']) !!}
								</td>
							</tr>
						</tbody>
						<tfoot>
							<tr>
								<th>Nombre Usuario</th>
							</tr>
						</tfoot> --}}
					<a href="{{URL('user')}}" role="button" class="btn btn-secondary">Volver</a>
					{!!Form::button('Guardar',['type'=>'submit','class'=>'btn btn-danger'])!!}
				{!! Form::close() !!}
			</div>
		</div>
	</div>
@stop